import React from 'react'

const Choice = () => <div>aaa</div>

export default Choice