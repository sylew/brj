import React from 'react'
import Chatbot from './Chatbot'

const ChatbotHistory = () => {
    return (
        <div>
            aaa
            <Chatbot />
        </div>
    )
}

export default ChatbotHistory