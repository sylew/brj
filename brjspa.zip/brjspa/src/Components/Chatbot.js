import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'


class Chatbot extends Component {
    render(){
        return (
            <div className="chatbot">
                <h1 class="center slideDown">How may we help you?</h1>
                <NavLink to="/Page">
                    <button class="btn waves-effect waves-light btn-large slideUp" type="submit" name="action">
                        <i class="material-icons">navigate_next</i>
                    </button>
                </NavLink>
            </div>
        )
    }
}

export default Chatbot